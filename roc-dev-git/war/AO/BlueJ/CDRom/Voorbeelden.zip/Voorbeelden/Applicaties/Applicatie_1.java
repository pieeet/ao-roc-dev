// Opstartklasse voor applicatie
import javax.swing.*;

class Applicatie_1 extends JFrame {
  public static void main( String args[] ) {
    JFrame frame = new Applicatie_1();
    frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
    frame.setSize( 400, 200 );
    frame.setTitle( "Applicatie 1" );
    frame.setVisible( true );
  }
} 
